export default function Home() {
  return (
    <main style={{ padding: 40, fontFamily: 'Arial' }}>
      <h1>TKD Grupo Cala</h1>
      <p>Página inicial del proyecto.</p>
    </main>
  );
}